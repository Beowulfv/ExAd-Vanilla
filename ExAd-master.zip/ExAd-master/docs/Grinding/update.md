#Grinding  
## Instructions:   

### v0.7.7 
* Replace "mpmissions\Exile.<map>\ExAdClient\Grinding"
* Replace and pack "@ExileServer\addons\exad_grinding"

### v0.7.6 
* Replace or merge "mpmissions\Exile.<map>\ExAdClient\Grinding\customize.sqf"
* Replace or merge "mpmissions\Exile.<map>\stringtable.xml"
* Replace "mpmissions\Exile.<map>\ExAdClient\Grinding" - Big update
* Replace and pack "@ExileServer\addons\exad_grinding"  
  
### v0.7.3 
* Replace "mpmissions\Exile.<map>\ExAdClient\Grinding\postInit.sqf"
 
### v0.6.1  
* Replace "ExAdClient\Grinding\Functions"
 
### v0.6.0  
* Full installation
