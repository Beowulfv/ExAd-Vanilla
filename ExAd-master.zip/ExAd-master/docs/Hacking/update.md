#Hacking  
## Instructions:   

### v0.7.7 
* Replace "mpmissions\Exile.<map>\ExAdClient\Hacking"
* Replace and pack "@ExileServer\addons\exad_hacking"

### v0.7.6 
* Replace or merge "mpmissions\Exile.<map>\ExAdClient\Hacking\customize.sqf"
* Replace or merge "mpmissions\Exile.<map>\stringtable.xml"
* Replace "mpmissions\Exile.<map>\ExAdClient\Hacking" - Big update
* Replace and pack "@ExileServer\addons\exad_hacking"  
 
###  v0.7.3
* Replace and pack "@ExileServer\addons\exad_hacking" 
* Replace "mpmissions\Exile.<map>\ExAdClient\Hacking\postInit.sqf" 

### v0.7.1 
* Replace and pack "@ExileServer\addons\exad_hacking"

### v0.7.0  
* Full installation
